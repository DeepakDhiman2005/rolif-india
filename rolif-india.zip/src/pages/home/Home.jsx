import { Title } from "react-head";

const Home = () => {
    return <>
        <main>
            <Title>Home</Title>
            <h2>home page!</h2>
        </main>
    </>
}

export default Home;