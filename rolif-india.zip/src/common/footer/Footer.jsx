const Footer = () => {
    return <>
        <footer>
            <h2>footer</h2>
        </footer>
    </>
}

export default Footer;