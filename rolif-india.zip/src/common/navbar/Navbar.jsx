const Navbar = () => {
    return <>
        <nav>
            <h2>navbar</h2>
        </nav>
    </>
}

export default Navbar;